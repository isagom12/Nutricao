alert("Oi, Lucas");
console.log("oi, isa");

var titulo = document querySelector("h1");
titulo textContent = "Lucas Nutrição";

var  trPaulo = documentSelector("#paulo");
